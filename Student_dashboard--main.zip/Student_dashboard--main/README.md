# Student Management Dashboard

React + Vite project for the College Student Dashboard assignment.

## Requirements

- Node.js LTS
- Visual Studio Code

## Run the project

```bash
npm install
npm run dev
```

Open the local URL shown by Vite, normally:

```text
http://localhost:5173/
```

## Production build

```bash
npm run build
```

## Project features

- Header with college and application title
- StudentProfile component using props
- SubjectList component using an array and map()
- Dynamic attendance percentage
- Eligible / Not Eligible conditional rendering
- ExamDetails component
- Footer
- Reusable StudentCard component
- View Profile button
- Multiple students
- Responsive CSS
