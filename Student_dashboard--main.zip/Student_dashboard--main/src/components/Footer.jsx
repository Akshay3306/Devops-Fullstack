function Footer() {
  return (
    <footer className="footer">
      <p>© 2026 SR University. All Rights Reserved.</p>
      <p>Student Management Dashboard</p>
    </footer>
  );
}

export default Footer;