function Attendance({ percentage }) {
  const isEligible = percentage >= 75;

  return (
    <article className="card attendance-card">
      <div className="card-title">
        <span className="icon">📊</span>
        <div>
          <h2>Attendance</h2>
          <p>Current attendance percentage</p>
        </div>
      </div>

      <div className="attendance-value">{percentage}%</div>

      <div
        className="progress-track"
        role="progressbar"
        aria-valuenow={percentage}
        aria-valuemin="0"
        aria-valuemax="100"
        aria-label={`Attendance ${percentage}%`}
      >
        <div
          className="progress-fill"
          style={{ width: `${percentage}%` }}
        />
      </div>

      <div className={isEligible ? "status eligible" : "status not-eligible"}>
        {isEligible ? "✓ Eligible" : "✕ Not Eligible"}
      </div>

      <p className="attendance-note">
        Minimum required attendance: 75%
      </p>
    </article>
  );
}

export default Attendance;