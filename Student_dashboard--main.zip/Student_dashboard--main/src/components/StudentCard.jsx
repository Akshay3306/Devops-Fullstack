function StudentCard({ student, isSelected, onViewProfile }) {
  return (
    <article className={`student-card ${isSelected ? "selected" : ""}`}>
      <div className="avatar">{student.name.charAt(0)}</div>

      <h3>{student.name}</h3>
      <p className="roll-number">{student.rollNumber}</p>
      <p className="branch">{student.branch}</p>

      <button
        type="button"
        className="profile-button"
        onClick={() => onViewProfile(student)}
      >
        {isSelected ? "Profile Selected" : "View Profile"}
      </button>
    </article>
  );
}

export default StudentCard;