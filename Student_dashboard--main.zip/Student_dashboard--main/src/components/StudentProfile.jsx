function StudentProfile({ student }) {
  return (
    <article className="card">
      <div className="card-title">
        <span className="icon">👤</span>
        <div>
          <h2>Student Profile</h2>
          <p>Personal academic information</p>
        </div>
      </div>

      <div className="profile-details">
        <div className="detail">
          <span className="label">Name</span>
          <strong>{student.name}</strong>
        </div>
        <div className="detail">
          <span className="label">Roll Number</span>
          <strong>{student.rollNumber}</strong>
        </div>
        <div className="detail">
          <span className="label">Branch</span>
          <strong>{student.branch}</strong>
        </div>
        <div className="detail">
          <span className="label">Year</span>
          <strong>{student.year}</strong>
        </div>
      </div>
    </article>
  );
}

export default StudentProfile;