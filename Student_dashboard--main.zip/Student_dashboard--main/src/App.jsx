import { useState } from "react";
import Header from "./components/Header";
import StudentProfile from "./components/StudentProfile";
import SubjectList from "./components/SubjectList";
import Attendance from "./components/Attendance";
import ExamDetails from "./components/ExamDetails";
import StudentCard from "./components/StudentCard";
import Footer from "./components/Footer";
import "./App.css";

const students = [
  {
    id: 1,
    name: "Pradeep Medaboina",
    rollNumber: "23CS102PE405",
    branch: "Computer Science Engineering",
    year: "3rd Year",
    attendance: 87,
  },
  {
    id: 2,
    name: "Rahul Kumar",
    rollNumber: "23CS102PE406",
    branch: "Computer Science Engineering",
    year: "3rd Year",
    attendance: 72,
  },
  {
    id: 3,
    name: "Ananya Sharma",
    rollNumber: "23CS102PE407",
    branch: "Computer Science Engineering",
    year: "3rd Year",
    attendance: 91,
  },
];

const subjects = [
  { id: 1, name: "DevOps and Full Stack", code: "23CS102PE405" },
  { id: 2, name: "Data Science", code: "23CS102PE406" },
  { id: 3, name: "Machine Learning", code: "23CS102PE407" },
  { id: 4, name: "Computer Networks", code: "23CS102PE408" },
  { id: 5, name: "Database Management Systems", code: "23CS102PE409" },
];

const exam = {
  name: "Mid-Term Examination",
  date: "25 September 2026",
  time: "10:00 AM - 1:00 PM",
  venue: "Block A - Room 204",
};

function App() {
  const [selectedStudent, setSelectedStudent] = useState(students[0]);

  return (
    <div className="app">
      <Header />

      <main className="container">
        <section className="hero">
          <div>
            <p className="eyebrow">COLLEGE STUDENT MANAGEMENT SYSTEM</p>
            <h1>Student Management Dashboard</h1>
            <p className="hero-text">
              View student profile, subjects, attendance, and examination information.
            </p>
          </div>
        </section>

        <section className="section">
          <div className="section-heading">
            <div>
              <h2>Students</h2>
              <p>Select a student to view their dashboard information.</p>
            </div>
          </div>

          <div className="student-cards">
            {students.map((student) => (
              <StudentCard
                key={student.id}
                student={student}
                isSelected={selectedStudent.id === student.id}
                onViewProfile={setSelectedStudent}
              />
            ))}
          </div>
        </section>

        <section className="dashboard-grid">
          <StudentProfile student={selectedStudent} />
          <Attendance percentage={selectedStudent.attendance} />
          <SubjectList subjects={subjects} />
          <ExamDetails exam={exam} />
        </section>
      </main>

      <Footer />
    </div>
  );
}

export default App;